import React from "react";

const ErrorComponent = () => {
    return <h1>This Component crashed</h1>;
};

export default ErrorComponent;
