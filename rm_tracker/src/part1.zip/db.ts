export const users = [
    {
        id: 1,
        name: "daseul",
    },
    {
        id: 2,
        name: "nico",
    },
];
